enum class Color {

        RED, BLUE, YELLOW, ORANGE, PINK;

        fun print() {
            println(this.name)
        }

        fun printNum() {
            println(this.ordinal + 1)
        }
    }
    enum class WeekDay {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;


        fun print() {
            println(when (this) {
                MONDAY -> "Monday"
                TUESDAY -> "Tuesday"
                WEDNESDAY -> "Wednesday"
                THURSDAY -> "Thursday"
                FRIDAY -> "Friday"
                SATURDAY -> "Saturday"
                SUNDAY -> "Sunday"
            })
        }

        fun printNum() {
            println(this.ordinal + 1)
        }
    }

    enum class Kosmetica(var k: Int, var price: Double) {
        POMADA(3, 100.0), PALETKA(2, 150.0), TONALNIK(3, 299.9);

        fun printK() {
            println("Кол-во:" + this.k)
        }

        fun Kol(kos: Kosmetica): Int {
            println("Введите сколько товара вам необходимо")
            kos.k = readLine()!!.toInt()
            return kos.k
        }

        fun Price() {
            println("Стоимость 1-го товара:" + this.price)
        }

        fun FinishPrice(): Double {
            return k * price
        }
        fun Skidka():Double {
            println("Скидка на POMADA 10%, на PALETKA 15%, на TONALNIK 20%")
            return when (this)
            {
                POMADA->this.k*this.price*0.9
                PALETKA->this.k*this.price*0.15
                TONALNIK->this.k*this.price*5
            }


        }


    }
enum class Kvartira(var price:Double, var coust:Double)
{
    ODNOKOMNOTNAYA(0.0,32000.0), DVYHKOMNOTNAYA(0.0, 70000.0), TREHKOMNOTNAYA(0.0,120000.0);
    fun Pr(kv:Kvartira):Double
    {
        println("Введите сумму денег,которая у вас в предпочтении при покупке квартиры")
        kv.price= readLine()!!.toDouble()
        return kv.price
    }
    fun K():Int{
        println("Введите на каком этаже вы бы хотели жить, мы учтём все предпочтения и от этого не поменяется цена(1-8 этаж)")
        var k= readLine()!!.toInt()
        return k
    }

    fun Coust():String
    {
        var a:String
        a= "Вам невозможно приобрести данную квартиру"
        var b:String
        b="Ваша сумма подходит для приобритения данной квартиры"
        if(this.price<this.coust)
       return a
        else return b
    }
    fun P():String
    {
        if(this.price>this.coust)
       println("Скидка на  квартиру, если вы студент\nВы являеетесь студентом?(Введите Да либо Нет)")
        var b= readLine()!!.toString()
        if (b=="Да")
            return "С учётом скидки="+ this.coust*0.8
        else return "Без учёта скидки="+ this.coust

    }



}





