fun main() {
    //1
 /*   val day = WeekDay.MONDAY
    val c = Color.PINK

    day.print()
    day.printNum()

    c.print()
    c.printNum()*/

    // 2
    try {
    /*    println("Введите название косметического товара, который вы хотели бы приобрести")
        var kos = readln()
        val tov = Kosmetica.valueOf(kos)
       tov.Kol(tov)
        tov.printK()
       tov.Price()
        tov.Skidka()
        println("Общая стоимость товара:" + tov.FinishPrice())
        println("Со скидкой="+tov.Skidka())*/


        //2
        println("Введите какую квартиру вы бы хотели приобрести")
        var kvar = readln()
        val kv = Kvartira.valueOf(kvar)
        kv.Pr(kv)
   println(kv.Coust())
        kv.K()
        println(kv.P())

    } catch (e: Exception) {
        println("Введите данные корректно")
    }
}